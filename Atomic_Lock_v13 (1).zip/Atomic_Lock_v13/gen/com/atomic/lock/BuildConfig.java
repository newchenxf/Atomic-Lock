/** Automatically generated file. DO NOT MODIFY */
package com.atomic.lock;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}